import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Heart, ShoppingCart } from 'lucide-react';
import { useState, useEffect } from 'react';
import { apiCall } from '../lib/supabase';
import { useAuth } from '../lib/auth';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  featured: boolean;
}

interface FeaturedProductsProps {
  onNavigate: (page: string) => void;
}

export function FeaturedProducts({ onNavigate }: FeaturedProductsProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState<string[]>([]);
  const { user, userData } = useAuth();

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (userData?.favorites) {
      setFavorites(userData.favorites);
    }
  }, [userData]);

  const loadProducts = async () => {
    try {
      const data = await apiCall('/products');
      // Filtrar produtos em destaque e limitar a 9
      const featured = data.products
        .filter((p: Product) => p.featured)
        .slice(0, 9);
      
      // Se não houver produtos em destaque suficientes, pegar os primeiros
      if (featured.length < 9) {
        const remaining = 9 - featured.length;
        const additional = data.products
          .filter((p: Product) => !p.featured)
          .slice(0, remaining);
        setProducts([...featured, ...additional]);
      } else {
        setProducts(featured);
      }
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (productId: string) => {
    if (!user) {
      onNavigate('login');
      return;
    }

    try {
      if (favorites.includes(productId)) {
        await apiCall(`/favorites/${productId}`, { method: 'DELETE' });
        setFavorites(favorites.filter(id => id !== productId));
      } else {
        await apiCall(`/favorites/${productId}`, { method: 'POST' });
        setFavorites([...favorites, productId]);
      }
    } catch (error) {
      console.error('Erro ao atualizar favoritos:', error);
    }
  };

  if (loading) {
    return (
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-serif mb-4">Produtos em Destaque</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(9)].map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-2xl h-96 animate-pulse" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-white" id="produtos">
      <div className="container mx-auto px-4">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-serif mb-4">
            Produtos em Destaque
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto mb-4" />
          <p className="text-gray-600 max-w-2xl mx-auto">
            Seleção especial dos nossos doces mais amados e procurados
          </p>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="bg-white rounded-2xl overflow-hidden border border-gray-100 hover:border-pink-200 transition-all hover:shadow-xl">
                {/* Image */}
                <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-pink-50 to-purple-50">
                  {product.image ? (
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-6xl">🎂</span>
                    </div>
                  )}
                  
                  {/* Favorite Button */}
                  <button
                    onClick={() => toggleFavorite(product.id)}
                    className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors"
                  >
                    <Heart
                      className={`size-5 transition-colors ${
                        favorites.includes(product.id)
                          ? 'fill-pink-500 text-pink-500'
                          : 'text-gray-600'
                      }`}
                    />
                  </button>

                  {/* Price Tag */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full">
                    <span className="text-pink-600 font-semibold">
                      R$ {product.price.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 group-hover:text-pink-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {product.description || 'Delicioso doce artesanal feito com ingredientes selecionados'}
                  </p>

                  <Button
                    onClick={() => onNavigate('products')}
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 gap-2"
                  >
                    <ShoppingCart className="size-4" />
                    Ver Mais
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Button
            size="lg"
            variant="outline"
            onClick={() => onNavigate('products')}
            className="text-lg px-8"
          >
            Ver Todos os Produtos
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
