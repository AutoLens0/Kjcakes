import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Phone, MessageSquare } from 'lucide-react';
import { useState } from 'react';
import { apiCall } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';

export function OrderForm() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    product: '',
    details: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.phone || !formData.product) {
      toast.error('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    setLoading(true);

    try {
      await apiCall('/encomendas', {
        method: 'POST',
        body: JSON.stringify(formData),
      });

      toast.success('Encomenda recebida! Entraremos em contato em breve 🎉');
      
      // Limpar formulário
      setFormData({
        name: '',
        phone: '',
        product: '',
        details: '',
      });
    } catch (error) {
      console.error('Erro ao enviar encomenda:', error);
      toast.error('Erro ao enviar encomenda. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsApp = () => {
    const message = `Olá! Gostaria de fazer uma encomenda:\n\nProduto: ${formData.product || 'A definir'}\nDetalhes: ${formData.details || 'Gostaria de mais informações'}`;
    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <section className="py-20 bg-gradient-to-br from-pink-50 to-purple-50" id="encomendas">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-serif mb-4">
              Faça Sua Encomenda
            </h2>
            <div className="w-20 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto mb-4" />
            <p className="text-gray-600 max-w-2xl mx-auto">
              Preencha o formulário abaixo ou entre em contato diretamente pelo WhatsApp
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-2xl p-8 shadow-xl"
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="name">Nome Completo *</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Seu nome"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">WhatsApp *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="(11) 99999-9999"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="product">Produto Desejado *</Label>
                  <Input
                    id="product"
                    type="text"
                    placeholder="Ex: Bolo de Chocolate 2kg"
                    value={formData.product}
                    onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                    required
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="details">Detalhes da Encomenda</Label>
                  <Textarea
                    id="details"
                    placeholder="Conte-nos mais sobre o que você precisa (data, decoração, sabores...)"
                    value={formData.details}
                    onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                    rows={4}
                    className="mt-2"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 gap-2"
                >
                  {loading ? (
                    'Enviando...'
                  ) : (
                    <>
                      <MessageSquare className="size-4" />
                      Enviar Encomenda
                    </>
                  )}
                </Button>
              </form>
            </motion.div>

            {/* WhatsApp Direct */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              {/* WhatsApp Card */}
              <div className="bg-green-500 rounded-2xl p-8 text-white">
                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
                  <Phone className="size-8" />
                </div>
                
                <h3 className="text-2xl font-semibold mb-4">
                  Prefere Falar no WhatsApp?
                </h3>
                
                <p className="mb-6 opacity-90">
                  Atendimento rápido e personalizado. Tire suas dúvidas e faça
                  seu pedido diretamente conosco!
                </p>

                <Button
                  onClick={handleWhatsApp}
                  className="w-full bg-white text-green-600 hover:bg-gray-100 gap-2"
                >
                  <Phone className="size-4" />
                  Abrir WhatsApp
                </Button>
              </div>

              {/* Info Cards */}
              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h4 className="font-semibold mb-4">Por que escolher a KJ Cakes?</h4>
                <ul className="space-y-3 text-sm text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="text-pink-500">✓</span>
                    <span>Ingredientes premium e frescos</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-500">✓</span>
                    <span>Personalização completa do seu pedido</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-500">✓</span>
                    <span>Entrega pontual e segura</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-500">✓</span>
                    <span>Atendimento atencioso e profissional</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-500">✓</span>
                    <span>Mais de 500 clientes satisfeitos</span>
                  </li>
                </ul>
              </div>

              {/* Timeline */}
              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <h4 className="font-semibold mb-4">Como Funciona</h4>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center flex-shrink-0 font-semibold">
                      1
                    </div>
                    <div>
                      <div className="font-medium">Faça seu pedido</div>
                      <div className="text-sm text-gray-600">Via formulário ou WhatsApp</div>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center flex-shrink-0 font-semibold">
                      2
                    </div>
                    <div>
                      <div className="font-medium">Confirmação</div>
                      <div className="text-sm text-gray-600">Entramos em contato em até 2h</div>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center flex-shrink-0 font-semibold">
                      3
                    </div>
                    <div>
                      <div className="font-medium">Produção</div>
                      <div className="text-sm text-gray-600">Seu doce feito com carinho</div>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center flex-shrink-0 font-semibold">
                      4
                    </div>
                    <div>
                      <div className="font-medium">Entrega</div>
                      <div className="text-sm text-gray-600">Receba na data combinada</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
