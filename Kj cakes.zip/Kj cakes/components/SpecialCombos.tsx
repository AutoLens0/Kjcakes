import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Package, Gift, Heart, Sparkles } from 'lucide-react';

interface SpecialCombosProps {
  onNavigate: (page: string) => void;
}

export function SpecialCombos({ onNavigate }: SpecialCombosProps) {
  const combos = [
    {
      id: '1',
      name: 'Combo Romântico',
      description: 'Bolo + 12 cupcakes + Chocolates premium',
      price: 189.90,
      icon: Heart,
      color: 'from-pink-500 to-rose-500',
      bgColor: 'from-pink-50 to-rose-50',
      popular: true,
    },
    {
      id: '2',
      name: 'Combo Festa',
      description: 'Bolo grande + 50 docinhos + Torta',
      price: 349.90,
      icon: Gift,
      color: 'from-purple-500 to-indigo-500',
      bgColor: 'from-purple-50 to-indigo-50',
      popular: false,
    },
    {
      id: '3',
      name: 'Combo Premium',
      description: 'Bolo decorado + Brigadeiros gourmet + Macarons',
      price: 279.90,
      icon: Sparkles,
      color: 'from-orange-500 to-yellow-500',
      bgColor: 'from-orange-50 to-yellow-50',
      popular: false,
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-100 to-purple-100 rounded-full mb-4">
            <Package className="size-4 text-pink-600" />
            <span className="text-pink-600 font-semibold text-sm">Ofertas Especiais</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-serif mb-4">Combos Especiais</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto mb-4" />
          <p className="text-gray-600 max-w-2xl mx-auto">
            Economize com nossos combos perfeitos para qualquer ocasião
          </p>
        </motion.div>

        {/* Combos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {combos.map((combo, index) => (
            <motion.div
              key={combo.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              {combo.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-4 py-1 rounded-full text-sm font-semibold shadow-lg">
                    Mais Vendido
                  </div>
                </div>
              )}

              <div className={`bg-gradient-to-br ${combo.bgColor} rounded-2xl p-8 border-2 border-transparent group-hover:border-pink-200 transition-all hover:shadow-xl`}>
                {/* Icon */}
                <div className={`w-16 h-16 bg-gradient-to-br ${combo.color} rounded-2xl flex items-center justify-center mb-6`}>
                  <combo.icon className="size-8 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-2xl font-semibold mb-3">{combo.name}</h3>
                <p className="text-gray-600 mb-6 min-h-[3rem]">{combo.description}</p>

                {/* Price */}
                <div className="mb-6">
                  <div className="text-sm text-gray-600 mb-1">A partir de</div>
                  <div className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                    R$ {combo.price.toFixed(2)}
                  </div>
                </div>

                {/* Button */}
                <Button
                  onClick={() => {
                    document.getElementById('encomendas')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`w-full bg-gradient-to-r ${combo.color} hover:opacity-90`}
                >
                  Encomendar Combo
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="inline-block bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-8">
            <Package className="size-12 text-pink-600 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold mb-2">Precisa de algo personalizado?</h3>
            <p className="text-gray-600 mb-6">
              Criamos combos personalizados para sua ocasião especial
            </p>
            <Button
              size="lg"
              onClick={() => {
                document.getElementById('encomendas')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
            >
              Fale Conosco
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
