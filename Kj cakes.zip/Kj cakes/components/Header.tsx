import { useState } from 'react';
import { Menu, X, ShoppingCart, User, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { useAuth } from '../lib/auth';

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function Header({ onNavigate, currentPage }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, userData, signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
      onNavigate('home');
    } catch (error) {
      console.error('Erro ao sair:', error);
    }
  };

  const menuItems = [
    { label: 'Home', page: 'home' },
    { label: 'Produtos', page: 'products' },
    { label: 'Sobre', page: 'about' },
    { label: 'Contato', page: 'contact' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-purple-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">KJ</span>
            </div>
            <span className="text-2xl font-serif">KJ Cakes</span>
          </button>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className={`transition-colors ${
                  currentPage === item.page
                    ? 'text-pink-500 font-medium'
                    : 'text-gray-700 hover:text-pink-500'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                {userData?.role === 'admin' && (
                  <Button
                    variant="outline"
                    onClick={() => onNavigate('admin')}
                    className="border-purple-500 text-purple-600 hover:bg-purple-50"
                  >
                    Painel Admin
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => onNavigate('profile')}
                  className="gap-2"
                >
                  <User className="size-4" />
                  {userData?.name || 'Perfil'}
                </Button>
                <Button
                  variant="ghost"
                  onClick={handleSignOut}
                  className="gap-2"
                >
                  <LogOut className="size-4" />
                  Sair
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" onClick={() => onNavigate('login')}>
                  Entrar
                </Button>
                <Button onClick={() => onNavigate('signup')}>
                  Cadastrar
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2"
          >
            {isMenuOpen ? (
              <X className="size-6" />
            ) : (
              <Menu className="size-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <nav className="flex flex-col space-y-4">
              {menuItems.map((item) => (
                <button
                  key={item.page}
                  onClick={() => {
                    onNavigate(item.page);
                    setIsMenuOpen(false);
                  }}
                  className={`text-left py-2 px-4 rounded-lg transition-colors ${
                    currentPage === item.page
                      ? 'bg-pink-50 text-pink-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              
              <div className="pt-4 border-t border-gray-100 space-y-2">
                {user ? (
                  <>
                    {userData?.role === 'admin' && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          onNavigate('admin');
                          setIsMenuOpen(false);
                        }}
                        className="w-full border-purple-500 text-purple-600"
                      >
                        Painel Admin
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      onClick={() => {
                        onNavigate('profile');
                        setIsMenuOpen(false);
                      }}
                      className="w-full gap-2"
                    >
                      <User className="size-4" />
                      {userData?.name || 'Perfil'}
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={handleSignOut}
                      className="w-full gap-2"
                    >
                      <LogOut className="size-4" />
                      Sair
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        onNavigate('login');
                        setIsMenuOpen(false);
                      }}
                      className="w-full"
                    >
                      Entrar
                    </Button>
                    <Button
                      onClick={() => {
                        onNavigate('signup');
                        setIsMenuOpen(false);
                      }}
                      className="w-full"
                    >
                      Cadastrar
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
