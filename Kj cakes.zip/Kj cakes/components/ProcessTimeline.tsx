import { motion } from 'motion/react';
import { MessageSquare, CheckCircle, ChefHat, Truck } from 'lucide-react';

export function ProcessTimeline() {
  const steps = [
    {
      icon: MessageSquare,
      title: 'Faça Seu Pedido',
      description: 'Escolha seus produtos favoritos e envie sua encomenda',
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-blue-50',
    },
    {
      icon: CheckCircle,
      title: 'Confirmação Rápida',
      description: 'Confirmamos todos os detalhes em até 2 horas',
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50',
    },
    {
      icon: ChefHat,
      title: 'Produção Artesanal',
      description: 'Seu doce é preparado com carinho e ingredientes premium',
      color: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-50',
    },
    {
      icon: Truck,
      title: 'Entrega Pontual',
      description: 'Receba na data e hora combinadas, sempre fresco',
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-50',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="container mx-auto px-4">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif mb-4">Como Funciona</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto mb-4" />
          <p className="text-gray-600 max-w-2xl mx-auto">
            Do pedido à entrega: um processo simples e transparente
          </p>
        </motion.div>

        {/* Timeline - Desktop */}
        <div className="hidden lg:block">
          <div className="relative">
            {/* Line */}
            <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-orange-500 -translate-y-1/2" />

            {/* Steps */}
            <div className="grid grid-cols-4 gap-8">
              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  className="relative"
                >
                  {/* Card */}
                  <div className="bg-white rounded-2xl p-6 shadow-lg border-2 border-transparent hover:border-pink-200 transition-all relative z-10">
                    {/* Icon */}
                    <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                      <step.icon className="size-8 text-white" />
                    </div>

                    {/* Number */}
                    <div className="absolute -top-3 -left-3 w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                      {index + 1}
                    </div>

                    {/* Content */}
                    <h3 className="text-xl font-semibold mb-2 text-center">{step.title}</h3>
                    <p className="text-sm text-gray-600 text-center">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Timeline - Mobile */}
        <div className="lg:hidden space-y-6">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex gap-4"
            >
              {/* Timeline */}
              <div className="flex flex-col items-center">
                <div className={`w-12 h-12 bg-gradient-to-br ${step.color} rounded-full flex items-center justify-center text-white font-bold flex-shrink-0`}>
                  {index + 1}
                </div>
                {index < steps.length - 1 && (
                  <div className="w-0.5 h-full bg-gradient-to-b from-pink-300 to-purple-300 mt-2" />
                )}
              </div>

              {/* Content */}
              <div className="bg-white rounded-2xl p-6 shadow-lg flex-1 mb-4">
                <div className={`w-12 h-12 ${step.bgColor} rounded-xl flex items-center justify-center mb-4`}>
                  <step.icon className={`size-6 bg-gradient-to-br ${step.color} bg-clip-text text-transparent`} style={{ WebkitTextFillColor: 'transparent' }} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-sm text-gray-600">{step.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="inline-block bg-white rounded-2xl p-8 shadow-xl">
            <h3 className="text-2xl font-semibold mb-2">Pronto para começar?</h3>
            <p className="text-gray-600 mb-6">
              Seu doce perfeito está a apenas alguns cliques de distância
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#produtos"
                className="inline-flex items-center justify-center px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-lg hover:from-pink-600 hover:to-purple-600 transition-all font-medium"
              >
                Ver Produtos
              </a>
              <a
                href="#encomendas"
                className="inline-flex items-center justify-center px-6 py-3 border-2 border-pink-500 text-pink-600 rounded-lg hover:bg-pink-50 transition-all font-medium"
              >
                Fazer Encomenda
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
