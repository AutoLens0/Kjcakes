import { motion } from 'motion/react';
import { Award, Heart, Users } from 'lucide-react';

export function AboutSection() {
  const features = [
    {
      icon: Heart,
      title: 'Feito com Amor',
      description: 'Cada doce é preparado com dedicação e carinho especial',
    },
    {
      icon: Award,
      title: 'Ingredientes Premium',
      description: 'Utilizamos apenas os melhores ingredientes selecionados',
    },
    {
      icon: Users,
      title: 'Experiência de 10 Anos',
      description: 'Uma década criando momentos doces e memoráveis',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-pink-50 to-purple-50" id="sobre">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1628394726060-37cc4da4cf03?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXN0cnklMjBjaGVmJTIwa2l0Y2hlbnxlbnwxfHx8fDE3NjQxOTczNDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Nossa confeiteira"
                className="w-full aspect-[4/3] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>
            
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-pink-400 to-purple-500 rounded-2xl -z-10" />
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="inline-block px-4 py-2 bg-pink-100 text-pink-600 rounded-full text-sm mb-4">
              Nossa História
            </span>
            
            <h2 className="text-4xl md:text-5xl font-serif mb-6">
              A Arte de Criar Momentos Doces
            </h2>
            
            <p className="text-gray-700 mb-6 leading-relaxed">
              Há mais de 10 anos, a KJ Cakes nasceu de uma paixão por transformar
              ingredientes simples em experiências memoráveis. Cada receita é
              cuidadosamente desenvolvida para criar não apenas um doce, mas uma
              lembrança que permanece no coração.
            </p>
            
            <p className="text-gray-700 mb-8 leading-relaxed">
              Nossa missão é fazer parte dos seus momentos mais especiais - desde
              aniversários e casamentos até aquele café da tarde que merece um
              toque especial. Com ingredientes premium e muito amor, criamos doces
              que encantam os olhos e conquistam o paladar.
            </p>

            {/* Features */}
            <div className="space-y-4">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-4 p-4 bg-white rounded-xl"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <feature.icon className="size-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
