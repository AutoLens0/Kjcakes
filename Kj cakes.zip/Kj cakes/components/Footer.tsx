import { Phone, Mail, MapPin, Clock, Instagram, Facebook } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e Descrição */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-400 to-purple-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">KJ</span>
              </div>
              <span className="text-2xl font-serif">KJ Cakes</span>
            </div>
            <p className="text-gray-400 text-sm">
              Doces artesanais feitos com amor e os melhores ingredientes.
              Transformando momentos em memórias deliciosas.
            </p>
          </div>

          {/* Contato */}
          <div>
            <h3 className="font-semibold mb-4">Contato</h3>
            <div className="space-y-3 text-sm text-gray-400">
              <div className="flex items-start gap-2">
                <Phone className="size-4 mt-0.5 flex-shrink-0" />
                <span>(11) 99999-9999</span>
              </div>
              <div className="flex items-start gap-2">
                <Mail className="size-4 mt-0.5 flex-shrink-0" />
                <span>contato@kjcakes.com.br</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="size-4 mt-0.5 flex-shrink-0" />
                <span>São Paulo, SP - Brasil</span>
              </div>
            </div>
          </div>

          {/* Horário */}
          <div>
            <h3 className="font-semibold mb-4">Horário de Funcionamento</h3>
            <div className="space-y-2 text-sm text-gray-400">
              <div className="flex items-start gap-2">
                <Clock className="size-4 mt-0.5 flex-shrink-0" />
                <div>
                  <div>Segunda a Sexta</div>
                  <div className="text-white">9h - 18h</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="size-4 mt-0.5 flex-shrink-0" />
                <div>
                  <div>Sábado</div>
                  <div className="text-white">9h - 14h</div>
                </div>
              </div>
              <div className="text-pink-400 mt-2">Domingo: Fechado</div>
            </div>
          </div>

          {/* Redes Sociais */}
          <div>
            <h3 className="font-semibold mb-4">Redes Sociais</h3>
            <div className="space-y-3">
              <a
                href="https://instagram.com/kjcakes"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-pink-400 transition-colors"
              >
                <Instagram className="size-5" />
                <span className="text-sm">@kjcakes</span>
              </a>
              <a
                href="https://facebook.com/kjcakes"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-pink-400 transition-colors"
              >
                <Facebook className="size-5" />
                <span className="text-sm">/kjcakes</span>
              </a>
            </div>
            <div className="mt-6">
              <p className="text-sm text-gray-400 mb-2">
                Encomendas via WhatsApp:
              </p>
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors text-sm"
              >
                <Phone className="size-4" />
                Fazer Pedido
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>© {new Date().getFullYear()} KJ Cakes. Todos os direitos reservados.</p>
          <p className="mt-2">
            Feito com 💜 e muito açúcar
          </p>
        </div>
      </div>
    </footer>
  );
}
