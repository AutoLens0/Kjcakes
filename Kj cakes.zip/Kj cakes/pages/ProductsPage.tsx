import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { Heart, Search, ShoppingCart, Filter } from 'lucide-react';
import { apiCall } from '../lib/supabase';
import { useAuth } from '../lib/auth';
import { toast } from 'sonner@2.0.3';

interface ProductsPageProps {
  onNavigate: (page: string) => void;
}

export function ProductsPage({ onNavigate }: ProductsPageProps) {
  const [products, setProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, userData } = useAuth();

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (userData?.favorites) {
      setFavorites(userData.favorites);
    }
  }, [userData]);

  useEffect(() => {
    filterProducts();
  }, [searchTerm, selectedCategory, products]);

  const loadProducts = async () => {
    try {
      const data = await apiCall('/products');
      setProducts(data.products || []);
      setFilteredProducts(data.products || []);
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterProducts = () => {
    let filtered = products;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    setFilteredProducts(filtered);
  };

  const toggleFavorite = async (productId: string) => {
    if (!user) {
      toast.error('Faça login para adicionar favoritos');
      onNavigate('login');
      return;
    }

    try {
      if (favorites.includes(productId)) {
        await apiCall(`/favorites/${productId}`, { method: 'DELETE' });
        setFavorites(favorites.filter((id) => id !== productId));
        toast.success('Removido dos favoritos');
      } else {
        await apiCall(`/favorites/${productId}`, { method: 'POST' });
        setFavorites([...favorites, productId]);
        toast.success('Adicionado aos favoritos ❤️');
      }
    } catch (error) {
      console.error('Erro ao atualizar favoritos:', error);
      toast.error('Erro ao atualizar favoritos');
    }
  };

  const categories = ['all', 'bolos', 'tortas', 'docinhos', 'cupcakes', 'combos'];
  const categoryLabels: Record<string, string> = {
    all: 'Todos',
    bolos: 'Bolos',
    tortas: 'Tortas',
    docinhos: 'Docinhos',
    cupcakes: 'Cupcakes',
    combos: 'Combos',
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl h-96 animate-pulse" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-serif mb-2">Nossos Produtos</h1>
          <p className="text-gray-600">Explore nossa seleção de doces artesanais</p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 space-y-4"
        >
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar produtos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 py-6 bg-white"
            />
          </div>

          {/* Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <Filter className="size-5 text-gray-600 flex-shrink-0" />
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setSelectedCategory(category)}
                variant={selectedCategory === category ? 'default' : 'outline'}
                className={
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-pink-500 to-purple-500'
                    : ''
                }
              >
                {categoryLabels[category]}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <Search className="size-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold mb-2">Nenhum produto encontrado</h3>
            <p className="text-gray-600 mb-6">
              Tente ajustar os filtros ou buscar por outro termo
            </p>
            <Button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
            >
              Limpar Filtros
            </Button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="group"
              >
                <Card className="overflow-hidden hover:shadow-xl transition-shadow">
                  {/* Image */}
                  <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-pink-50 to-purple-50">
                    {product.image ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span className="text-6xl">🎂</span>
                      </div>
                    )}

                    {/* Favorite Button */}
                    <button
                      onClick={() => toggleFavorite(product.id)}
                      className="absolute top-3 right-3 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors"
                    >
                      <Heart
                        className={`size-5 transition-colors ${
                          favorites.includes(product.id)
                            ? 'fill-pink-500 text-pink-500'
                            : 'text-gray-600'
                        }`}
                      />
                    </button>

                    {/* Price Tag */}
                    <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full">
                      <span className="text-pink-600 font-semibold">
                        R$ {product.price.toFixed(2)}
                      </span>
                    </div>

                    {/* Featured Badge */}
                    {product.featured && (
                      <div className="absolute top-3 left-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                        Destaque
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3 className="font-semibold mb-2 group-hover:text-pink-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                      {product.description || 'Delicioso doce artesanal'}
                    </p>

                    <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 gap-2">
                      <ShoppingCart className="size-4" />
                      Encomendar
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
