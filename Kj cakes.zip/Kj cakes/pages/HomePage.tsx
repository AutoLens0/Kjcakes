import { HeroSection } from '../components/HeroSection';
import { FeaturedProducts } from '../components/FeaturedProducts';
import { SpecialCombos } from '../components/SpecialCombos';
import { AboutSection } from '../components/AboutSection';
import { ProcessTimeline } from '../components/ProcessTimeline';
import { Testimonials } from '../components/Testimonials';
import { OrderForm } from '../components/OrderForm';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div>
      <HeroSection onNavigate={onNavigate} />
      <FeaturedProducts onNavigate={onNavigate} />
      <SpecialCombos onNavigate={onNavigate} />
      <AboutSection />
      <ProcessTimeline />
      <Testimonials />
      <OrderForm />
    </div>
  );
}
