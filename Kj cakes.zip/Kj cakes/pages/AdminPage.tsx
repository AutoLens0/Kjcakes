import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card } from '../components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Package,
  Plus,
  Edit2,
  Trash2,
  ShoppingBag,
  Users,
  Ticket,
  MessageSquare,
  Star,
  Save,
} from 'lucide-react';
import { useAuth } from '../lib/auth';
import { apiCall } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';
import { Switch } from '../components/ui/switch';

interface AdminPageProps {
  onNavigate: (page: string) => void;
}

export function AdminPage({ onNavigate }: AdminPageProps) {
  const { user, userData } = useAuth();
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [encomendas, setEncomendas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Product form state
  const [isProductDialogOpen, setIsProductDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: '',
    image: '',
    category: 'geral',
    featured: false,
  });

  // Coupon form state
  const [couponForm, setCouponForm] = useState({
    code: '',
    discount: '',
    expiresAt: '',
  });

  useEffect(() => {
    if (!user || userData?.role !== 'admin') {
      toast.error('Acesso negado. Apenas administradores.');
      onNavigate('home');
      return;
    }

    loadData();
  }, [user, userData]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [productsData, ordersData, encomendasData] = await Promise.all([
        apiCall('/products'),
        apiCall('/admin/orders'),
        apiCall('/admin/encomendas'),
      ]);

      setProducts(productsData.products || []);
      setOrders(ordersData.orders || []);
      setEncomendas(encomendasData.encomendas || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  // Product Management
  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!productForm.name || !productForm.price) {
      toast.error('Nome e preço são obrigatórios');
      return;
    }

    try {
      if (editingProduct) {
        await apiCall(`/products/${editingProduct.id}`, {
          method: 'PUT',
          body: JSON.stringify(productForm),
        });
        toast.success('Produto atualizado com sucesso!');
      } else {
        await apiCall('/products', {
          method: 'POST',
          body: JSON.stringify(productForm),
        });
        toast.success('Produto criado com sucesso!');
      }

      setIsProductDialogOpen(false);
      resetProductForm();
      loadData();
    } catch (error) {
      console.error('Erro ao salvar produto:', error);
      toast.error('Erro ao salvar produto');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Tem certeza que deseja deletar este produto?')) return;

    try {
      await apiCall(`/products/${id}`, { method: 'DELETE' });
      toast.success('Produto deletado com sucesso!');
      loadData();
    } catch (error) {
      console.error('Erro ao deletar produto:', error);
      toast.error('Erro ao deletar produto');
    }
  };

  const handleEditProduct = (product: any) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      description: product.description || '',
      price: product.price.toString(),
      image: product.image || '',
      category: product.category || 'geral',
      featured: product.featured || false,
    });
    setIsProductDialogOpen(true);
  };

  const resetProductForm = () => {
    setEditingProduct(null);
    setProductForm({
      name: '',
      description: '',
      price: '',
      image: '',
      category: 'geral',
      featured: false,
    });
  };

  // Order Management
  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      await apiCall(`/admin/orders/${orderId}`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      });
      toast.success('Status atualizado com sucesso!');
      loadData();
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
      toast.error('Erro ao atualizar status');
    }
  };

  // Coupon Management
  const handleCouponSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!couponForm.code || !couponForm.discount) {
      toast.error('Código e desconto são obrigatórios');
      return;
    }

    try {
      await apiCall('/coupons', {
        method: 'POST',
        body: JSON.stringify(couponForm),
      });
      toast.success('Cupom criado com sucesso!');
      setCouponForm({ code: '', discount: '', expiresAt: '' });
    } catch (error) {
      console.error('Erro ao criar cupom:', error);
      toast.error('Erro ao criar cupom');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-24 pb-12 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-pink-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Carregando painel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-24 pb-12">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-serif mb-2">Painel Administrativo</h1>
          <p className="text-gray-600">Gerencie todos os aspectos da sua confeitaria</p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Produtos</p>
                <p className="text-3xl font-bold text-pink-600">{products.length}</p>
              </div>
              <Package className="size-12 text-pink-300" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Pedidos</p>
                <p className="text-3xl font-bold text-purple-600">{orders.length}</p>
              </div>
              <ShoppingBag className="size-12 text-purple-300" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Encomendas</p>
                <p className="text-3xl font-bold text-blue-600">{encomendas.length}</p>
              </div>
              <MessageSquare className="size-12 text-blue-300" />
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Destaques</p>
                <p className="text-3xl font-bold text-orange-600">
                  {products.filter((p) => p.featured).length}
                </p>
              </div>
              <Star className="size-12 text-orange-300" />
            </div>
          </Card>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="products" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="products">Produtos</TabsTrigger>
              <TabsTrigger value="orders">Pedidos</TabsTrigger>
              <TabsTrigger value="encomendas">Encomendas</TabsTrigger>
              <TabsTrigger value="coupons">Cupons</TabsTrigger>
            </TabsList>

            {/* Products Tab */}
            <TabsContent value="products" className="space-y-6">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold">Gerenciar Produtos</h2>
                  <Dialog open={isProductDialogOpen} onOpenChange={setIsProductDialogOpen}>
                    <DialogTrigger asChild>
                      <Button
                        onClick={resetProductForm}
                        className="bg-gradient-to-r from-pink-500 to-purple-500 gap-2"
                      >
                        <Plus className="size-4" />
                        Novo Produto
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>
                          {editingProduct ? 'Editar Produto' : 'Novo Produto'}
                        </DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleProductSubmit} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">Nome do Produto *</Label>
                            <Input
                              id="name"
                              value={productForm.name}
                              onChange={(e) =>
                                setProductForm({ ...productForm, name: e.target.value })
                              }
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="price">Preço (R$) *</Label>
                            <Input
                              id="price"
                              type="number"
                              step="0.01"
                              value={productForm.price}
                              onChange={(e) =>
                                setProductForm({ ...productForm, price: e.target.value })
                              }
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="description">Descrição</Label>
                          <Textarea
                            id="description"
                            value={productForm.description}
                            onChange={(e) =>
                              setProductForm({ ...productForm, description: e.target.value })
                            }
                            rows={3}
                          />
                        </div>

                        <div>
                          <Label htmlFor="image">URL da Imagem</Label>
                          <Input
                            id="image"
                            type="url"
                            value={productForm.image}
                            onChange={(e) =>
                              setProductForm({ ...productForm, image: e.target.value })
                            }
                            placeholder="https://..."
                          />
                        </div>

                        <div>
                          <Label htmlFor="category">Categoria</Label>
                          <Select
                            value={productForm.category}
                            onValueChange={(value) =>
                              setProductForm({ ...productForm, category: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="geral">Geral</SelectItem>
                              <SelectItem value="bolos">Bolos</SelectItem>
                              <SelectItem value="tortas">Tortas</SelectItem>
                              <SelectItem value="docinhos">Docinhos</SelectItem>
                              <SelectItem value="cupcakes">Cupcakes</SelectItem>
                              <SelectItem value="combos">Combos</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Switch
                            id="featured"
                            checked={productForm.featured}
                            onCheckedChange={(checked) =>
                              setProductForm({ ...productForm, featured: checked })
                            }
                          />
                          <Label htmlFor="featured">Produto em destaque</Label>
                        </div>

                        <div className="flex gap-2 pt-4">
                          <Button type="submit" className="flex-1 gap-2">
                            <Save className="size-4" />
                            Salvar Produto
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => {
                              setIsProductDialogOpen(false);
                              resetProductForm();
                            }}
                          >
                            Cancelar
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {products.map((product) => (
                    <Card key={product.id} className="p-4">
                      <div className="aspect-square bg-gradient-to-br from-pink-50 to-purple-50 rounded-lg mb-3 overflow-hidden">
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <span className="text-4xl">🎂</span>
                          </div>
                        )}
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <h3 className="font-semibold">{product.name}</h3>
                          {product.featured && (
                            <Star className="size-4 fill-yellow-400 text-yellow-400" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {product.description}
                        </p>
                        <p className="text-pink-600 font-semibold">
                          R$ {product.price.toFixed(2)}
                        </p>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditProduct(product)}
                            className="flex-1 gap-1"
                          >
                            <Edit2 className="size-3" />
                            Editar
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteProduct(product.id)}
                            className="text-red-600 hover:text-red-700 gap-1"
                          >
                            <Trash2 className="size-3" />
                            Deletar
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                {products.length === 0 && (
                  <div className="text-center py-12">
                    <Package className="size-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Nenhum produto cadastrado</p>
                  </div>
                )}
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders" className="space-y-6">
              <Card className="p-6">
                <h2 className="text-2xl font-semibold mb-6">Pedidos dos Clientes</h2>

                <div className="space-y-4">
                  {orders.map((order) => (
                    <Card key={order.id} className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="font-semibold">Pedido #{order.id.slice(0, 8)}</div>
                          <div className="text-sm text-gray-600">
                            {new Date(order.createdAt).toLocaleString('pt-BR')}
                          </div>
                          <div className="text-sm text-gray-600">
                            {order.items?.length || 0} item(ns)
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-pink-600 text-lg">
                            R$ {order.total.toFixed(2)}
                          </div>
                          <Select
                            value={order.status}
                            onValueChange={(value) =>
                              handleUpdateOrderStatus(order.id, value)
                            }
                          >
                            <SelectTrigger className="w-40 mt-2">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="recebido">Recebido</SelectItem>
                              <SelectItem value="em_producao">Em Produção</SelectItem>
                              <SelectItem value="concluido">Concluído</SelectItem>
                              <SelectItem value="entregue">Entregue</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      {order.deliveryAddress && (
                        <div className="text-sm text-gray-600 mt-2">
                          <strong>Endereço:</strong> {order.deliveryAddress}
                        </div>
                      )}
                      {order.phone && (
                        <div className="text-sm text-gray-600">
                          <strong>Telefone:</strong> {order.phone}
                        </div>
                      )}
                    </Card>
                  ))}

                  {orders.length === 0 && (
                    <div className="text-center py-12">
                      <ShoppingBag className="size-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-600">Nenhum pedido ainda</p>
                    </div>
                  )}
                </div>
              </Card>
            </TabsContent>

            {/* Encomendas Tab */}
            <TabsContent value="encomendas" className="space-y-6">
              <Card className="p-6">
                <h2 className="text-2xl font-semibold mb-6">Encomendas Recebidas</h2>

                <div className="space-y-4">
                  {encomendas.map((encomenda) => (
                    <Card key={encomenda.id} className="p-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <div className="text-sm text-gray-600">Cliente</div>
                          <div className="font-semibold">{encomenda.name}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">WhatsApp</div>
                          <div className="font-semibold">{encomenda.phone}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Data</div>
                          <div className="font-semibold">
                            {new Date(encomenda.createdAt).toLocaleDateString('pt-BR')}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 pt-3 border-t">
                        <div className="text-sm text-gray-600">Produto</div>
                        <div className="font-semibold">{encomenda.product}</div>
                      </div>
                      {encomenda.details && (
                        <div className="mt-2">
                          <div className="text-sm text-gray-600">Detalhes</div>
                          <div className="text-sm">{encomenda.details}</div>
                        </div>
                      )}
                    </Card>
                  ))}

                  {encomendas.length === 0 && (
                    <div className="text-center py-12">
                      <MessageSquare className="size-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-600">Nenhuma encomenda ainda</p>
                    </div>
                  )}
                </div>
              </Card>
            </TabsContent>

            {/* Coupons Tab */}
            <TabsContent value="coupons" className="space-y-6">
              <Card className="p-6">
                <h2 className="text-2xl font-semibold mb-6">Criar Cupom de Desconto</h2>

                <form onSubmit={handleCouponSubmit} className="space-y-4 max-w-2xl">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="couponCode">Código do Cupom *</Label>
                      <Input
                        id="couponCode"
                        value={couponForm.code}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })
                        }
                        placeholder="PROMO10"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="discount">Desconto (%) *</Label>
                      <Input
                        id="discount"
                        type="number"
                        step="0.01"
                        value={couponForm.discount}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, discount: e.target.value })
                        }
                        placeholder="10"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="expiresAt">Data de Expiração (opcional)</Label>
                    <Input
                      id="expiresAt"
                      type="datetime-local"
                      value={couponForm.expiresAt}
                      onChange={(e) =>
                        setCouponForm({ ...couponForm, expiresAt: e.target.value })
                      }
                    />
                  </div>

                  <Button type="submit" className="gap-2">
                    <Ticket className="size-4" />
                    Criar Cupom
                  </Button>
                </form>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
