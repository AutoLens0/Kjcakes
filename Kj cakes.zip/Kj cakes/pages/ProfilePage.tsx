import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card } from '../components/ui/card';
import { User, Mail, Heart, ShoppingBag, Edit2, Save } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { apiCall } from '../lib/supabase';
import { toast } from 'sonner@2.0.3';

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, userData, refreshUserData } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('');
  const [orders, setOrders] = useState<any[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      onNavigate('login');
      return;
    }
    
    if (userData) {
      setName(userData.name || '');
      loadOrders();
      loadFavorites();
    }
  }, [user, userData]);

  const loadOrders = async () => {
    try {
      const data = await apiCall('/orders');
      setOrders(data.orders || []);
    } catch (error) {
      console.error('Erro ao carregar pedidos:', error);
    }
  };

  const loadFavorites = async () => {
    if (!userData?.favorites || userData.favorites.length === 0) {
      setFavorites([]);
      return;
    }

    try {
      const productsData = await apiCall('/products');
      const favoriteProducts = productsData.products.filter((p: any) =>
        userData.favorites.includes(p.id)
      );
      setFavorites(favoriteProducts);
    } catch (error) {
      console.error('Erro ao carregar favoritos:', error);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await apiCall('/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ name }),
      });
      await refreshUserData();
      toast.success('Perfil atualizado com sucesso!');
      setIsEditing(false);
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      toast.error('Erro ao atualizar perfil');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'recebido':
        return 'bg-blue-100 text-blue-800';
      case 'em_producao':
        return 'bg-yellow-100 text-yellow-800';
      case 'concluido':
        return 'bg-green-100 text-green-800';
      case 'entregue':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'recebido':
        return 'Recebido';
      case 'em_producao':
        return 'Em Produção';
      case 'concluido':
        return 'Concluído';
      case 'entregue':
        return 'Entregue';
      default:
        return status;
    }
  };

  if (!user || !userData) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 pt-24 pb-12">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-serif mb-2">Meu Perfil</h1>
          <p className="text-gray-600">Gerencie suas informações e pedidos</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <Card className="p-6">
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full mx-auto flex items-center justify-center mb-4">
                  <User className="size-12 text-white" />
                </div>
                <h2 className="text-2xl font-semibold">{userData.name}</h2>
                <p className="text-gray-600 text-sm">{user.email}</p>
              </div>

              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="mt-2"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleSave}
                      disabled={loading}
                      className="flex-1 gap-2"
                    >
                      <Save className="size-4" />
                      Salvar
                    </Button>
                    <Button
                      onClick={() => {
                        setIsEditing(false);
                        setName(userData.name || '');
                      }}
                      variant="outline"
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={() => setIsEditing(true)}
                  variant="outline"
                  className="w-full gap-2"
                >
                  <Edit2 className="size-4" />
                  Editar Perfil
                </Button>
              )}

              <div className="mt-6 pt-6 border-t space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Pedidos</span>
                  <span className="font-semibold">{orders.length}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Favoritos</span>
                  <span className="font-semibold">{favorites.length}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Membro desde</span>
                  <span className="font-semibold">
                    {new Date(userData.createdAt).toLocaleDateString('pt-BR')}
                  </span>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 space-y-8"
          >
            {/* Orders */}
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-6">
                <ShoppingBag className="size-5 text-pink-600" />
                <h3 className="text-xl font-semibold">Meus Pedidos</h3>
              </div>

              {orders.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="size-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">Você ainda não fez nenhum pedido</p>
                  <Button onClick={() => onNavigate('products')}>
                    Ver Produtos
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="border border-gray-200 rounded-lg p-4 hover:border-pink-200 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="font-semibold">Pedido #{order.id.slice(0, 8)}</div>
                          <div className="text-sm text-gray-600">
                            {new Date(order.createdAt).toLocaleDateString('pt-BR')}
                          </div>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                          {getStatusLabel(order.status)}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600 mb-2">
                        {order.items.length} item(ns)
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-pink-600">
                          R$ {order.total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Favorites */}
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-6">
                <Heart className="size-5 text-pink-600" />
                <h3 className="text-xl font-semibold">Meus Favoritos</h3>
              </div>

              {favorites.length === 0 ? (
                <div className="text-center py-12">
                  <Heart className="size-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">Você ainda não tem favoritos</p>
                  <Button onClick={() => onNavigate('products')}>
                    Explorar Produtos
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {favorites.map((product) => (
                    <div
                      key={product.id}
                      className="border border-gray-200 rounded-lg overflow-hidden hover:border-pink-200 transition-colors cursor-pointer"
                      onClick={() => onNavigate('products')}
                    >
                      <div className="aspect-square bg-gradient-to-br from-pink-50 to-purple-50">
                        {product.image ? (
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <span className="text-4xl">🎂</span>
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <h4 className="font-semibold mb-1">{product.name}</h4>
                        <p className="text-pink-600 font-semibold">
                          R$ {product.price.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
