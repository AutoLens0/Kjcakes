import { useState } from 'react';
import { AuthProvider } from './lib/auth';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { ProfilePage } from './pages/ProfilePage';
import { ProductsPage } from './pages/ProductsPage';
import { AdminPage } from './pages/AdminPage';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'products':
        return <ProductsPage onNavigate={setCurrentPage} />;
      case 'login':
        return <LoginPage onNavigate={setCurrentPage} />;
      case 'signup':
        return <SignupPage onNavigate={setCurrentPage} />;
      case 'profile':
        return <ProfilePage onNavigate={setCurrentPage} />;
      case 'admin':
        return <AdminPage onNavigate={setCurrentPage} />;
      case 'about':
        return (
          <div className="pt-20">
            <HomePage onNavigate={setCurrentPage} />
          </div>
        );
      case 'contact':
        return (
          <div className="pt-20">
            <HomePage onNavigate={setCurrentPage} />
          </div>
        );
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  const showHeaderFooter = !['login', 'signup'].includes(currentPage);

  return (
    <AuthProvider>
      <div className="min-h-screen flex flex-col">
        {showHeaderFooter && (
          <Header onNavigate={setCurrentPage} currentPage={currentPage} />
        )}
        
        <main className="flex-1">
          {renderPage()}
        </main>

        {showHeaderFooter && <Footer />}
        
        {/* WhatsApp Floating Button */}
        {showHeaderFooter && <WhatsAppButton />}

        {/* Toast Notifications */}
        <Toaster position="top-right" richColors />
      </div>
    </AuthProvider>
  );
}
