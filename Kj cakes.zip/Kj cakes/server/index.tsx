import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-f9f2ff95/health", (c) => {
  return c.json({ status: "ok" });
});

// ============================================
// AUTENTICAÇÃO
// ============================================

// Signup - Criar novo usuário
app.post("/make-server-f9f2ff95/auth/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: "Email, senha e nome são obrigatórios" }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role: 'user' },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Erro ao criar usuário: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    // Criar perfil do usuário no KV
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      name,
      role: 'user',
      favorites: [],
      createdAt: new Date().toISOString(),
    });

    return c.json({ 
      message: "Usuário criado com sucesso! Email confirmado automaticamente.",
      user: data.user 
    });
  } catch (error) {
    console.log(`Erro no signup: ${error}`);
    return c.json({ error: "Erro ao criar usuário" }, 500);
  }
});

// Signup Admin - Criar novo administrador
app.post("/make-server-f9f2ff95/auth/signup-admin", async (c) => {
  try {
    const { email, password, name, adminSecret } = await c.req.json();

    // Verificar secret do admin (em produção, use uma chave segura)
    if (adminSecret !== "KJ_CAKES_ADMIN_2024") {
      return c.json({ error: "Secret de admin inválido" }, 403);
    }

    if (!email || !password || !name) {
      return c.json({ error: "Email, senha e nome são obrigatórios" }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role: 'admin' },
      email_confirm: true
    });

    if (error) {
      console.log(`Erro ao criar admin: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    // Criar perfil do admin no KV
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      name,
      role: 'admin',
      createdAt: new Date().toISOString(),
    });

    return c.json({ 
      message: "Administrador criado com sucesso!",
      user: data.user 
    });
  } catch (error) {
    console.log(`Erro no signup admin: ${error}`);
    return c.json({ error: "Erro ao criar administrador" }, 500);
  }
});

// Middleware de autenticação
async function requireAuth(c: any, next: any) {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  
  if (!accessToken) {
    return c.json({ error: "Token não fornecido" }, 401);
  }

  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (error || !user) {
    return c.json({ error: "Token inválido ou expirado" }, 401);
  }

  c.set('user', user);
  await next();
}

// Middleware de admin
async function requireAdmin(c: any, next: any) {
  const user = c.get('user');
  const userData = await kv.get(`user:${user.id}`);
  
  if (!userData || userData.role !== 'admin') {
    return c.json({ error: "Acesso negado. Apenas administradores." }, 403);
  }

  await next();
}

// Get user profile
app.get("/make-server-f9f2ff95/auth/profile", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const userData = await kv.get(`user:${user.id}`);
    
    return c.json({ user: userData });
  } catch (error) {
    console.log(`Erro ao buscar perfil: ${error}`);
    return c.json({ error: "Erro ao buscar perfil" }, 500);
  }
});

// Update user profile
app.put("/make-server-f9f2ff95/auth/profile", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const { name } = await c.req.json();
    
    const userData = await kv.get(`user:${user.id}`);
    
    if (!userData) {
      return c.json({ error: "Usuário não encontrado" }, 404);
    }

    userData.name = name || userData.name;
    userData.updatedAt = new Date().toISOString();

    await kv.set(`user:${user.id}`, userData);
    
    return c.json({ message: "Perfil atualizado com sucesso", user: userData });
  } catch (error) {
    console.log(`Erro ao atualizar perfil: ${error}`);
    return c.json({ error: "Erro ao atualizar perfil" }, 500);
  }
});

// ============================================
// PRODUTOS
// ============================================

// Listar todos os produtos
app.get("/make-server-f9f2ff95/products", async (c) => {
  try {
    const products = await kv.getByPrefix("product:");
    return c.json({ products: products || [] });
  } catch (error) {
    console.log(`Erro ao listar produtos: ${error}`);
    return c.json({ error: "Erro ao listar produtos" }, 500);
  }
});

// Buscar produto por ID
app.get("/make-server-f9f2ff95/products/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const product = await kv.get(`product:${id}`);
    
    if (!product) {
      return c.json({ error: "Produto não encontrado" }, 404);
    }
    
    return c.json({ product });
  } catch (error) {
    console.log(`Erro ao buscar produto: ${error}`);
    return c.json({ error: "Erro ao buscar produto" }, 500);
  }
});

// Criar produto (Admin apenas)
app.post("/make-server-f9f2ff95/products", requireAuth, requireAdmin, async (c) => {
  try {
    const { name, description, price, image, category, featured } = await c.req.json();
    
    if (!name || !price) {
      return c.json({ error: "Nome e preço são obrigatórios" }, 400);
    }

    const id = crypto.randomUUID();
    const product = {
      id,
      name,
      description: description || "",
      price: parseFloat(price),
      image: image || "",
      category: category || "geral",
      featured: featured || false,
      createdAt: new Date().toISOString(),
    };

    await kv.set(`product:${id}`, product);
    
    return c.json({ message: "Produto criado com sucesso", product });
  } catch (error) {
    console.log(`Erro ao criar produto: ${error}`);
    return c.json({ error: "Erro ao criar produto" }, 500);
  }
});

// Atualizar produto (Admin apenas)
app.put("/make-server-f9f2ff95/products/:id", requireAuth, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id');
    const updates = await c.req.json();
    
    const product = await kv.get(`product:${id}`);
    
    if (!product) {
      return c.json({ error: "Produto não encontrado" }, 404);
    }

    const updatedProduct = {
      ...product,
      ...updates,
      id, // Manter o ID original
      updatedAt: new Date().toISOString(),
    };

    await kv.set(`product:${id}`, updatedProduct);
    
    return c.json({ message: "Produto atualizado com sucesso", product: updatedProduct });
  } catch (error) {
    console.log(`Erro ao atualizar produto: ${error}`);
    return c.json({ error: "Erro ao atualizar produto" }, 500);
  }
});

// Deletar produto (Admin apenas)
app.delete("/make-server-f9f2ff95/products/:id", requireAuth, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id');
    
    const product = await kv.get(`product:${id}`);
    
    if (!product) {
      return c.json({ error: "Produto não encontrado" }, 404);
    }

    await kv.del(`product:${id}`);
    
    return c.json({ message: "Produto deletado com sucesso" });
  } catch (error) {
    console.log(`Erro ao deletar produto: ${error}`);
    return c.json({ error: "Erro ao deletar produto" }, 500);
  }
});

// ============================================
// FAVORITOS
// ============================================

// Adicionar aos favoritos
app.post("/make-server-f9f2ff95/favorites/:productId", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const productId = c.req.param('productId');
    
    const userData = await kv.get(`user:${user.id}`);
    
    if (!userData) {
      return c.json({ error: "Usuário não encontrado" }, 404);
    }

    if (!userData.favorites) {
      userData.favorites = [];
    }

    if (!userData.favorites.includes(productId)) {
      userData.favorites.push(productId);
      await kv.set(`user:${user.id}`, userData);
    }
    
    return c.json({ message: "Produto adicionado aos favoritos", favorites: userData.favorites });
  } catch (error) {
    console.log(`Erro ao adicionar favorito: ${error}`);
    return c.json({ error: "Erro ao adicionar favorito" }, 500);
  }
});

// Remover dos favoritos
app.delete("/make-server-f9f2ff95/favorites/:productId", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const productId = c.req.param('productId');
    
    const userData = await kv.get(`user:${user.id}`);
    
    if (!userData) {
      return c.json({ error: "Usuário não encontrado" }, 404);
    }

    if (userData.favorites) {
      userData.favorites = userData.favorites.filter((id: string) => id !== productId);
      await kv.set(`user:${user.id}`, userData);
    }
    
    return c.json({ message: "Produto removido dos favoritos", favorites: userData.favorites });
  } catch (error) {
    console.log(`Erro ao remover favorito: ${error}`);
    return c.json({ error: "Erro ao remover favorito" }, 500);
  }
});

// ============================================
// PEDIDOS
// ============================================

// Criar pedido
app.post("/make-server-f9f2ff95/orders", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const { items, total, deliveryAddress, phone } = await c.req.json();
    
    if (!items || items.length === 0) {
      return c.json({ error: "Pedido deve conter ao menos um item" }, 400);
    }

    const orderId = crypto.randomUUID();
    const order = {
      id: orderId,
      userId: user.id,
      items,
      total: parseFloat(total),
      deliveryAddress: deliveryAddress || "",
      phone: phone || "",
      status: "recebido", // recebido, em_producao, concluido, entregue
      createdAt: new Date().toISOString(),
    };

    await kv.set(`order:${orderId}`, order);
    
    return c.json({ message: "Pedido criado com sucesso", order });
  } catch (error) {
    console.log(`Erro ao criar pedido: ${error}`);
    return c.json({ error: "Erro ao criar pedido" }, 500);
  }
});

// Listar pedidos do usuário
app.get("/make-server-f9f2ff95/orders", requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const allOrders = await kv.getByPrefix("order:");
    
    const userOrders = allOrders.filter((order: any) => order.userId === user.id);
    
    return c.json({ orders: userOrders || [] });
  } catch (error) {
    console.log(`Erro ao listar pedidos: ${error}`);
    return c.json({ error: "Erro ao listar pedidos" }, 500);
  }
});

// Listar todos os pedidos (Admin apenas)
app.get("/make-server-f9f2ff95/admin/orders", requireAuth, requireAdmin, async (c) => {
  try {
    const orders = await kv.getByPrefix("order:");
    return c.json({ orders: orders || [] });
  } catch (error) {
    console.log(`Erro ao listar todos os pedidos: ${error}`);
    return c.json({ error: "Erro ao listar pedidos" }, 500);
  }
});

// Atualizar status do pedido (Admin apenas)
app.put("/make-server-f9f2ff95/admin/orders/:id", requireAuth, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id');
    const { status } = await c.req.json();
    
    const order = await kv.get(`order:${id}`);
    
    if (!order) {
      return c.json({ error: "Pedido não encontrado" }, 404);
    }

    order.status = status;
    order.updatedAt = new Date().toISOString();

    await kv.set(`order:${id}`, order);
    
    return c.json({ message: "Status do pedido atualizado", order });
  } catch (error) {
    console.log(`Erro ao atualizar pedido: ${error}`);
    return c.json({ error: "Erro ao atualizar pedido" }, 500);
  }
});

// ============================================
// CUPONS
// ============================================

// Criar cupom (Admin apenas)
app.post("/make-server-f9f2ff95/coupons", requireAuth, requireAdmin, async (c) => {
  try {
    const { code, discount, expiresAt } = await c.req.json();
    
    if (!code || !discount) {
      return c.json({ error: "Código e desconto são obrigatórios" }, 400);
    }

    const couponId = code.toUpperCase();
    const coupon = {
      id: couponId,
      code: couponId,
      discount: parseFloat(discount),
      expiresAt: expiresAt || null,
      active: true,
      createdAt: new Date().toISOString(),
    };

    await kv.set(`coupon:${couponId}`, coupon);
    
    return c.json({ message: "Cupom criado com sucesso", coupon });
  } catch (error) {
    console.log(`Erro ao criar cupom: ${error}`);
    return c.json({ error: "Erro ao criar cupom" }, 500);
  }
});

// Validar cupom
app.get("/make-server-f9f2ff95/coupons/:code", async (c) => {
  try {
    const code = c.req.param('code').toUpperCase();
    const coupon = await kv.get(`coupon:${code}`);
    
    if (!coupon || !coupon.active) {
      return c.json({ error: "Cupom inválido ou inativo" }, 404);
    }

    // Verificar expiração
    if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) {
      return c.json({ error: "Cupom expirado" }, 400);
    }
    
    return c.json({ coupon });
  } catch (error) {
    console.log(`Erro ao validar cupom: ${error}`);
    return c.json({ error: "Erro ao validar cupom" }, 500);
  }
});

// ============================================
// ENCOMENDAS (Formulário público)
// ============================================

app.post("/make-server-f9f2ff95/encomendas", async (c) => {
  try {
    const { name, phone, product, details } = await c.req.json();
    
    if (!name || !phone || !product) {
      return c.json({ error: "Nome, telefone e produto são obrigatórios" }, 400);
    }

    const encomendaId = crypto.randomUUID();
    const encomenda = {
      id: encomendaId,
      name,
      phone,
      product,
      details: details || "",
      status: "pendente",
      createdAt: new Date().toISOString(),
    };

    await kv.set(`encomenda:${encomendaId}`, encomenda);
    
    return c.json({ 
      message: "Encomenda recebida com sucesso! Entraremos em contato em breve.",
      encomenda 
    });
  } catch (error) {
    console.log(`Erro ao criar encomenda: ${error}`);
    return c.json({ error: "Erro ao criar encomenda" }, 500);
  }
});

// Listar encomendas (Admin apenas)
app.get("/make-server-f9f2ff95/admin/encomendas", requireAuth, requireAdmin, async (c) => {
  try {
    const encomendas = await kv.getByPrefix("encomenda:");
    return c.json({ encomendas: encomendas || [] });
  } catch (error) {
    console.log(`Erro ao listar encomendas: ${error}`);
    return c.json({ error: "Erro ao listar encomendas" }, 500);
  }
});

// ============================================
// SITE SETTINGS (Admin apenas)
// ============================================

// Get settings
app.get("/make-server-f9f2ff95/settings", async (c) => {
  try {
    const settings = await kv.get("site:settings");
    
    // Configurações padrão
    if (!settings) {
      const defaultSettings = {
        heroTitle: "Doces Feitos com Amor",
        heroSubtitle: "Transformando momentos especiais em experiências inesquecíveis",
        heroImage: "",
        aboutText: "Na KJ Cakes, cada doce é preparado com carinho e os melhores ingredientes.",
        aboutImage: "",
        phone: "+244 940 604 518",
        email: "contato@kjcakes.com.br",
        whatsapp: "+244 940604518",
        instagram: "@kjcakes",
        address: "Luanda,Benfica",
        hours: "Seg-Sex: 9h-18h | Sáb: 9h-14h",
      };
      await kv.set("site:settings", defaultSettings);
      return c.json({ settings: defaultSettings });
    }
    
    return c.json({ settings });
  } catch (error) {
    console.log(`Erro ao buscar configurações: ${error}`);
    return c.json({ error: "Erro ao buscar configurações" }, 500);
  }
});

// Update settings (Admin apenas)
app.put("/make-server-f9f2ff95/settings", requireAuth, requireAdmin, async (c) => {
  try {
    const updates = await c.req.json();
    const settings = await kv.get("site:settings") || {};
    
    const updatedSettings = {
      ...settings,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    await kv.set("site:settings", updatedSettings);
    
    return c.json({ message: "Configurações atualizadas com sucesso", settings: updatedSettings });
  } catch (error) {
    console.log(`Erro ao atualizar configurações: ${error}`);
    return c.json({ error: "Erro ao atualizar configurações" }, 500);
  }
});

Deno.serve(app.fetch);
