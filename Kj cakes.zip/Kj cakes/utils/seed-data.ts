// Script para popular produtos iniciais
// Este arquivo contém dados de exemplo que podem ser usados pelo admin

export const sampleProducts = [
  {
    name: 'Bolo de Chocolate Premium',
    description: 'Bolo de chocolate belga com recheio de brigadeiro gourmet e cobertura de ganache',
    price: 89.90,
    image: 'https://images.unsplash.com/photo-1607257882338-70f7dd2ae344?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBjYWtlJTIwZGVzc2VydHxlbnwxfHx8fDE3NjQxMjQ3NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'bolos',
    featured: true,
  },
  {
    name: 'Bolo de Aniversário Personalizado',
    description: 'Bolo decorado especialmente para o seu aniversário, com tema e cores personalizadas',
    price: 129.90,
    image: 'https://images.unsplash.com/photo-1664289597477-d5b2d266169d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaXJ0aGRheSUyMGNha2UlMjBjZWxlYnJhdGlvbnxlbnwxfHx8fDE3NjQxNzc0Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'bolos',
    featured: true,
  },
  {
    name: 'Cupcakes Variados (12un)',
    description: 'Seleção de 12 cupcakes em sabores variados: chocolate, baunilha, red velvet e limão',
    price: 59.90,
    image: 'https://images.unsplash.com/photo-1555526148-0fa555bb2e78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXBjYWtlcyUyMGNvbG9yZnVsfGVufDF8fHx8MTc2NDE4MTA1MHww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'cupcakes',
    featured: true,
  },
  {
    name: 'Bolo de Casamento 3 Andares',
    description: 'Bolo elegante de 3 andares, perfeito para casamentos e eventos especiais',
    price: 450.00,
    image: 'https://images.unsplash.com/photo-1584158531319-96912adae663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2FrZSUyMGVsZWdhbnR8ZW58MXx8fHwxNzY0MTUxNjg2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'bolos',
    featured: true,
  },
  {
    name: 'Torta de Morango',
    description: 'Torta cremosa com morangos frescos e chantilly caseiro',
    price: 69.90,
    image: '',
    category: 'tortas',
    featured: false,
  },
  {
    name: 'Brigadeiros Gourmet (30un)',
    description: '30 brigadeiros gourmet em sabores variados, com cobertura premium',
    price: 45.00,
    image: '',
    category: 'docinhos',
    featured: true,
  },
  {
    name: 'Bolo Red Velvet',
    description: 'Clássico bolo red velvet com cream cheese frosting',
    price: 79.90,
    image: '',
    category: 'bolos',
    featured: false,
  },
  {
    name: 'Torta de Limão',
    description: 'Torta de limão com merengue italiano e base crocante',
    price: 65.00,
    image: '',
    category: 'tortas',
    featured: true,
  },
  {
    name: 'Mini Cupcakes (24un)',
    description: '24 mini cupcakes perfeitos para festas e eventos',
    price: 48.00,
    image: '',
    category: 'cupcakes',
    featured: false,
  },
];

export const adminCredentials = {
  email: 'admin@kjcakes.com',
  password: 'admin123',
  name: 'Administrador KJ Cakes',
  adminSecret: 'KJ_CAKES_ADMIN_2024',
};

// Instruções para criar conta admin:
// 1. Acesse a página de cadastro
// 2. Use o endpoint /auth/signup-admin no backend
// 3. Forneça o adminSecret: KJ_CAKES_ADMIN_2024
