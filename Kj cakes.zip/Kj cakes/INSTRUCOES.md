# KJ Cakes - Sistema de Confeitaria

Sistema completo e moderno para confeitaria com vendas online, gestão de produtos e painel administrativo.

## 🎯 Funcionalidades

### Landing Page Pública
- ✅ Hero Section com animações elegantes
- ✅ Produtos em Destaque (grid 3x3)
- ✅ Combos Especiais com preços promocionais
- ✅ Seção Sobre com história da confeitaria
- ✅ Timeline do processo de produção
- ✅ Depoimentos de clientes
- ✅ Formulário de encomendas
- ✅ Botão flutuante do WhatsApp
- ✅ Footer completo com informações

### Sistema de Autenticação
- ✅ Cadastro de usuários
- ✅ Login/Logout
- ✅ Confirmação automática de email (email_confirm: true)
- ✅ Gestão de perfil
- ✅ Diferentes níveis de permissão (usuário/admin)

### Área do Usuário
- ✅ Visualizar perfil
- ✅ Editar informações pessoais
- ✅ Adicionar produtos aos favoritos
- ✅ Ver lista completa de produtos com filtros
- ✅ Buscar produtos por nome/descrição
- ✅ Visualizar histórico de pedidos
- ✅ Acompanhar status dos pedidos

### Painel Administrativo
- ✅ Dashboard com estatísticas
- ✅ Gerenciar produtos (criar, editar, deletar)
- ✅ Definir produtos em destaque
- ✅ Alterar imagens dos produtos
- ✅ Gerenciar categorias
- ✅ Visualizar e gerenciar pedidos
- ✅ Atualizar status dos pedidos
- ✅ Ver encomendas recebidas pelo formulário
- ✅ Criar cupons de desconto

### Extras Implementados
- ✅ Seção de Combos Especiais
- ✅ Animações suaves com Motion/React
- ✅ Chat rápido pelo WhatsApp integrado
- ✅ Sistema de cupons de desconto
- ✅ Timeline do processo de produção
- ✅ Sistema de favoritos
- ✅ Tela de pedidos com status em tempo real
- ✅ Design responsivo e moderno

## 🚀 Como Usar

### 1. Criar Conta de Usuário
1. Clique em "Cadastrar" no header
2. Preencha: nome, email e senha
3. Faça login automaticamente após o cadastro
4. O email é confirmado automaticamente

### 2. Criar Conta de Administrador

Para criar uma conta admin, você precisa usar uma ferramenta como Postman ou fazer uma chamada direta à API:

**Endpoint:** `POST /make-server-f9f2ff95/auth/signup-admin`

**Body:**
```json
{
  "email": "admin@kjcakes.com",
  "password": "admin123",
  "name": "Admin KJ Cakes",
  "adminSecret": "KJ_CAKES_ADMIN_2024"
}
```

**IMPORTANTE:** O `adminSecret` é obrigatório: `KJ_CAKES_ADMIN_2024`

Depois de criar o admin, faça login normalmente e você verá o botão "Painel Admin" no header.

### 3. Adicionar Produtos (Admin)
1. Acesse o Painel Admin
2. Clique em "Novo Produto"
3. Preencha as informações:
   - Nome do produto
   - Preço
   - Descrição
   - URL da imagem
   - Categoria
   - Marcar como destaque (opcional)
4. Clique em "Salvar Produto"

### 4. Gerenciar Produtos
- **Editar:** Clique no botão "Editar" do produto
- **Deletar:** Clique no botão "Deletar" (confirme a ação)
- **Destacar:** Ative o switch "Produto em destaque" ao editar

### 5. Visualizar Encomendas
- Acesse a aba "Encomendas" no painel admin
- Veja todas as encomendas feitas pelo formulário público
- Informações: nome, telefone, produto desejado e detalhes

### 6. Gerenciar Pedidos
- Acesse a aba "Pedidos" no painel admin
- Veja todos os pedidos dos usuários
- Atualize o status: Recebido → Em Produção → Concluído → Entregue

### 7. Criar Cupons
- Acesse a aba "Cupons" no painel admin
- Defina: código, desconto (%) e data de expiração (opcional)
- Cupons podem ser usados pelos clientes nos pedidos

## 📱 Funcionalidades para Usuários

### Favoritar Produtos
- Clique no ícone de coração nos cards de produtos
- Produtos favoritados aparecem no seu perfil
- Acesso rápido aos seus produtos preferidos

### Fazer Encomendas
1. Acesse "Produtos" ou role até a seção "Faça Sua Encomenda"
2. Preencha o formulário com:
   - Nome completo
   - WhatsApp
   - Produto desejado
   - Detalhes adicionais
3. Ou clique para falar direto no WhatsApp

### Buscar e Filtrar Produtos
- Use a barra de busca para encontrar produtos
- Filtre por categorias: Todos, Bolos, Tortas, Docinhos, Cupcakes, Combos
- Produtos marcados como "Destaque" aparecem na home

## 🎨 Estrutura do Sistema

### Backend (Supabase Edge Functions)
- **Autenticação:** Supabase Auth
- **Banco de Dados:** KV Store (key-value)
- **Rotas API:**
  - `/auth/*` - Autenticação e perfil
  - `/products/*` - Gerenciar produtos
  - `/favorites/*` - Sistema de favoritos
  - `/orders/*` - Pedidos de usuários
  - `/admin/*` - Rotas administrativas
  - `/encomendas` - Formulário público
  - `/coupons/*` - Cupons de desconto
  - `/settings` - Configurações do site

### Frontend (React + TypeScript)
- **Páginas:**
  - Home (Landing Page)
  - Produtos (catálogo completo)
  - Login/Cadastro
  - Perfil do Usuário
  - Painel Administrativo
  
- **Componentes:**
  - Header (navegação responsiva)
  - Footer (informações e contatos)
  - HeroSection (seção principal)
  - FeaturedProducts (produtos destaque)
  - SpecialCombos (combos promocionais)
  - AboutSection (sobre a confeitaria)
  - ProcessTimeline (como funciona)
  - Testimonials (depoimentos)
  - OrderForm (formulário de encomenda)
  - WhatsAppButton (botão flutuante)

## 🔐 Segurança

- Autenticação via Supabase Auth
- Rotas protegidas com middleware
- Verificação de permissões (user/admin)
- Tokens JWT para sessões
- Service Role Key protegida no backend
- Confirmação automática de email (sem exposição de dados)

## 📊 Dados Armazenados

### KV Store (Key-Value)
- `user:{userId}` - Dados do usuário
- `product:{productId}` - Produtos
- `order:{orderId}` - Pedidos
- `encomenda:{encomendaId}` - Encomendas públicas
- `coupon:{code}` - Cupons
- `site:settings` - Configurações do site

## 🎯 Próximos Passos Sugeridos

1. **Upload de Imagens:** Implementar upload direto de imagens (Supabase Storage)
2. **Email Marketing:** Sistema de newsletter
3. **Pagamento Online:** Integração com Stripe/Mercado Pago
4. **Notificações:** Push notifications para pedidos
5. **Relatórios:** Dashboard com gráficos de vendas
6. **Multi-idioma:** Suporte para inglês/espanhol
7. **Avaliações:** Sistema de reviews dos produtos
8. **Programa de Fidelidade:** Pontos e recompensas

## 💡 Dicas

- **Imagens:** Use URLs do Unsplash ou suas próprias imagens
- **Categorias:** Organize produtos em categorias para facilitar busca
- **Destaques:** Marque até 9 produtos como destaque para a home
- **Preços:** Use valores realistas para melhor experiência
- **Descrições:** Seja detalhado nas descrições dos produtos
- **WhatsApp:** Atualize o número no componente WhatsAppButton e Footer

## 🆘 Suporte

Para criar produtos de exemplo rapidamente:
1. Acesse o painel admin
2. Use os dados do arquivo `/utils/seed-data.ts` como referência
3. Copie e cole as informações ao criar novos produtos

---

**Desenvolvido com 💜 e muito açúcar!**
