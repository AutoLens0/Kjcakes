import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../utils/supabase/info';

// Cliente Supabase para o frontend
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// Função para fazer chamadas ao servidor
export async function apiCall(endpoint: string, options: RequestInit = {}) {
  const session = await supabase.auth.getSession();
  const token = session.data.session?.access_token || publicAnonKey;

  const response = await fetch(
    `https://${projectId}.supabase.co/functions/v1/make-server-f9f2ff95${endpoint}`,
    {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        ...options.headers,
      },
    }
  );

  if (!response.ok) {
    const error = await response.json();
    console.error(`API Error on ${endpoint}:`, error);
    throw new Error(error.error || 'Erro na requisição');
  }

  return response.json();
}
